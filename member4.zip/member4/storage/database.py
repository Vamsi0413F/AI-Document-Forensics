import sqlite3
import json
import os
from datetime import datetime
from typing import List, Dict, Any, Optional

DB_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(DB_DIR, "veridoc.db")


def init_db(db_path: str = DB_PATH) -> None:
    """Initialize SQLite tables for recent document forensic analyses."""
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS forensic_cases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            file_type TEXT NOT NULL,
            pages INTEGER DEFAULT 1,
            sha256 TEXT NOT NULL,
            severity TEXT NOT NULL,
            total_findings INTEGER DEFAULT 0,
            high_count INTEGER DEFAULT 0,
            medium_count INTEGER DEFAULT 0,
            low_count INTEGER DEFAULT 0,
            checks_completed INTEGER DEFAULT 0,
            checks_total INTEGER DEFAULT 10,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            formatted_time TEXT,
            case_data TEXT NOT NULL
        )
        """
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_sha256 ON forensic_cases(sha256)"
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_created_at ON forensic_cases(created_at DESC)"
    )
    conn.commit()
    conn.close()


def save_case(case: Dict[str, Any], db_path: str = DB_PATH) -> int:
    """Save or update a forensic analysis case in SQLite."""
    init_db(db_path)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    doc = case.get("document", {})
    summary = case.get("summary", {})
    filename = doc.get("filename", "unknown_document")
    file_type = doc.get("file_type", "PDF")
    pages = doc.get("pages", 1)
    sha256 = doc.get("sha256", "")
    severity = summary.get("severity", "LOW")
    total_findings = summary.get("total_findings", 0)
    high_count = summary.get("high", 0)
    medium_count = summary.get("medium", 0)
    low_count = summary.get("low", 0)
    checks_completed = summary.get("checks_completed", 0)
    checks_total = summary.get("checks_total", 10)

    formatted_time = datetime.now().strftime("%b %d • %I:%M %p")
    case_json = json.dumps(case)

    # Check if duplicate sha256 exists, update or insert
    cursor.execute(
        "SELECT id FROM forensic_cases WHERE sha256 = ? ORDER BY id DESC LIMIT 1",
        (sha256,),
    )
    existing = cursor.fetchone()

    if existing:
        case_id = existing[0]
        cursor.execute(
            """
            UPDATE forensic_cases
            SET filename = ?, file_type = ?, pages = ?, severity = ?,
                total_findings = ?, high_count = ?, medium_count = ?, low_count = ?,
                checks_completed = ?, checks_total = ?, formatted_time = ?, case_data = ?
            WHERE id = ?
            """,
            (
                filename,
                file_type,
                pages,
                severity,
                total_findings,
                high_count,
                medium_count,
                low_count,
                checks_completed,
                checks_total,
                formatted_time,
                case_json,
                case_id,
            ),
        )
    else:
        cursor.execute(
            """
            INSERT INTO forensic_cases (
                filename, file_type, pages, sha256, severity,
                total_findings, high_count, medium_count, low_count,
                checks_completed, checks_total, formatted_time, case_data
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                filename,
                file_type,
                pages,
                sha256,
                severity,
                total_findings,
                high_count,
                medium_count,
                low_count,
                checks_completed,
                checks_total,
                formatted_time,
                case_json,
            ),
        )
        case_id = cursor.lastrowid

    conn.commit()
    conn.close()
    return case_id


def get_recent_cases(limit: int = 10, db_path: str = DB_PATH) -> List[Dict[str, Any]]:
    """Retrieve recent analyses ordered by most recent."""
    init_db(db_path)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT id, filename, file_type, pages, sha256, severity,
               total_findings, high_count, medium_count, low_count,
               checks_completed, checks_total, created_at, formatted_time
        FROM forensic_cases
        ORDER BY id DESC
        LIMIT ?
        """,
        (limit,),
    )
    rows = cursor.fetchall()
    results = [dict(row) for row in rows]
    conn.close()
    return results


def get_case_by_id(case_id: int, db_path: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Retrieve full forensic case dict by ID."""
    init_db(db_path)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT case_data FROM forensic_cases WHERE id = ?", (case_id,))
    row = cursor.fetchone()
    conn.close()
    if row and row[0]:
        try:
            return json.loads(row[0])
        except Exception:
            return None
    return None


def rename_case(case_id: int, new_filename: str, db_path: str = DB_PATH) -> bool:
    """Rename a forensic case entry."""
    init_db(db_path)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    # Also update filename inside case_data JSON
    cursor.execute("SELECT case_data FROM forensic_cases WHERE id = ?", (case_id,))
    row = cursor.fetchone()
    if not row:
        conn.close()
        return False

    case_data = json.loads(row[0])
    if "document" in case_data:
        case_data["document"]["filename"] = new_filename
    updated_json = json.dumps(case_data)

    cursor.execute(
        "UPDATE forensic_cases SET filename = ?, case_data = ? WHERE id = ?",
        (new_filename, updated_json, case_id),
    )
    conn.commit()
    conn.close()
    return True


def delete_case(case_id: int, db_path: str = DB_PATH) -> bool:
    """Delete a forensic case by ID."""
    init_db(db_path)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM forensic_cases WHERE id = ?", (case_id,))
    conn.commit()
    conn.close()
    return True

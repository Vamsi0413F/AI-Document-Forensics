"""
Member 3 - Forensic Analysis Pipeline

Orchestrates the full analysis:
    Member 1 → Member 2 → Evidence Aggregation → Gemma 4 Reasoning

For image inputs, PDF-only Member 2 analyses are marked "not_applicable".
The deterministic pipeline survives Gemma failures.
"""

import logging
from pathlib import Path

from member1.pipeline import process_document
from member2.fingerprint import generate_sha256
from member2.formatting import analyze_formatting
from member2.metadata import extract_metadata
from member2.visual import analyze_visual_elements

from .evidence import aggregate_evidence
from .reasoning import call_gemma


logger = logging.getLogger(__name__)

PDF_EXTENSIONS = {".pdf"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg"}


def _is_pdf(file_path: str) -> bool:
    """Check if file is a PDF based on extension."""
    return Path(file_path).suffix.lower() in PDF_EXTENSIONS


def run_member2_analysis(file_path: str) -> dict:
    """
    Run all Member 2 analyses.

    For image inputs, PDF-only analyses (formatting, metadata, visual)
    are explicitly marked as "not_applicable".

    Fingerprint (SHA-256) works on any file type.
    """

    result = {
        "fingerprint": None,
        "formatting": "not_applicable",
        "metadata": "not_applicable",
        "visual": "not_applicable",
    }

    # SHA-256 works on any file
    try:
        result["fingerprint"] = {
            "sha256": generate_sha256(file_path),
        }
    except Exception as exc:
        logger.error("Fingerprint generation failed: %s", exc)
        result["fingerprint"] = {
            "sha256": None,
            "error": str(exc),
        }

    # PDF-only analyses
    if _is_pdf(file_path):
        try:
            result["formatting"] = analyze_formatting(file_path)
        except Exception as exc:
            logger.error("Formatting analysis failed: %s", exc)
            result["formatting"] = {"error": str(exc), "anomalies": []}

        try:
            result["metadata"] = extract_metadata(file_path)
        except Exception as exc:
            logger.error("Metadata extraction failed: %s", exc)
            result["metadata"] = {"error": str(exc), "has_metadata": None}

        try:
            result["visual"] = analyze_visual_elements(file_path)
        except Exception as exc:
            logger.error("Visual analysis failed: %s", exc)
            result["visual"] = {"error": str(exc), "images": []}

    return result


def run_full_analysis(file_path: str, api_key: str | None = None) -> dict:
    """
    Run the complete forensic analysis pipeline.

    Flow:
        1. Member 1: ingestion → extraction → fields → consistency
        2. Member 2: fingerprint, formatting, metadata, visual
        3. Evidence aggregation
        4. Gemma 4 reasoning

    Args:
        file_path: Absolute path to the uploaded document.
        api_key: Optional Gemini API key override.

    Returns:
        Complete analysis result dict.
    """

    # ----------------------------------------------------------
    # STEP 1: MEMBER 1 PIPELINE
    # ----------------------------------------------------------

    member1_result = process_document(file_path)

    if not member1_result.get("success"):
        return {
            "success": False,
            "error": member1_result.get("error", "Member 1 pipeline failed"),
            "stage": member1_result.get("stage", "member1"),
            "document": member1_result.get("document"),
            "member1": member1_result,
            "member2": None,
            "evidence": [],
            "fingerprint": None,
            "gemma": None,
        }

    # ----------------------------------------------------------
    # STEP 2: MEMBER 2 ANALYSIS
    # ----------------------------------------------------------

    member2_result = run_member2_analysis(file_path)

    # ----------------------------------------------------------
    # STEP 3: EVIDENCE AGGREGATION
    # ----------------------------------------------------------

    evidence = aggregate_evidence(member1_result, member2_result)

    # ----------------------------------------------------------
    # STEP 4: GEMMA 4 REASONING
    # ----------------------------------------------------------

    document_info = member1_result.get("document", {})
    extraction = member1_result.get("extraction", {})
    document_info["page_count"] = extraction.get("page_count", 0)

    fingerprint = member2_result.get("fingerprint", {"sha256": None})

    gemma_result = call_gemma(
        document_info=document_info,
        evidence=evidence,
        fingerprint=fingerprint,
        api_key=api_key,
    )

    # ----------------------------------------------------------
    # FINAL RESULT
    # ----------------------------------------------------------

    return {
        "success": True,
        "document": document_info,
        "member1": {
            "fields": member1_result.get("fields"),
            "consistency": member1_result.get("consistency"),
            "extraction": {
                "method": extraction.get("method"),
                "page_count": extraction.get("page_count", 0),
            },
        },
        "member2": {
            "formatting": (
                {
                    "fonts": member2_result["formatting"].get("fonts", {}),
                    "font_sizes": member2_result["formatting"].get("font_sizes", {}),
                    "dominant_font": member2_result["formatting"].get("dominant_font"),
                    "dominant_font_size": member2_result["formatting"].get("dominant_font_size"),
                    "anomaly_count": len(member2_result["formatting"].get("anomalies", [])),
                    "anomalies": member2_result["formatting"].get("anomalies", []),
                }
                if isinstance(member2_result.get("formatting"), dict)
                else "not_applicable"
            ),
            "metadata": member2_result.get("metadata"),
            "visual": member2_result.get("visual"),
        },
        "evidence": evidence,
        "fingerprint": fingerprint,
        "gemma": gemma_result,
    }

"""
Member 3 - Gemma 4 Forensic Reasoning

Sends normalized evidence to Gemma 4 (gemma-4-26b-a4b-it) via the
Google GenAI SDK and validates the structured response.

Gemma reasons over deterministic evidence — it does NOT perform OCR,
field extraction, hashing, or font detection.

The deterministic pipeline survives Gemma failures.
"""

import json
import os
import logging

from google import genai
from google.genai import types


logger = logging.getLogger(__name__)

MODEL_ID = "gemma-4-26b-a4b-it"

# ------------------------------------------------------------------
# RESPONSE SCHEMA (for structured JSON output)
# ------------------------------------------------------------------

RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "assessment": {
            "type": "object",
            "properties": {
                "level": {
                    "type": "string",
                    "enum": [
                        "LOW",
                        "MODERATE",
                        "HIGH",
                        "INSUFFICIENT_EVIDENCE",
                    ],
                },
                "summary": {"type": "string"},
            },
            "required": ["level", "summary"],
        },
        "key_findings": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "evidence_id": {"type": "string"},
                    "importance": {
                        "type": "string",
                        "enum": ["HIGH", "MEDIUM", "LOW"],
                    },
                    "reason": {"type": "string"},
                },
                "required": ["evidence_id", "importance", "reason"],
            },
        },
        "hypotheses": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "hypothesis": {"type": "string"},
                    "supporting_evidence_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "confidence": {
                        "type": "string",
                        "enum": ["LOW", "MEDIUM", "HIGH"],
                    },
                    "possible_benign_explanations": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                },
                "required": [
                    "hypothesis",
                    "supporting_evidence_ids",
                    "confidence",
                    "possible_benign_explanations",
                ],
            },
        },
        "manual_verification": {
            "type": "array",
            "items": {"type": "string"},
        },
        "limitations": {
            "type": "array",
            "items": {"type": "string"},
        },
    },
    "required": [
        "assessment",
        "key_findings",
        "hypotheses",
        "manual_verification",
        "limitations",
    ],
}


# ------------------------------------------------------------------
# SYSTEM PROMPT
# ------------------------------------------------------------------

SYSTEM_PROMPT = """You are a document forensics analyst. You receive structured evidence 
that deterministic analysis modules have already extracted from a document. 

YOUR ROLE:
- Reason over the provided evidence ONLY.
- Do NOT invent or fabricate observations. Only reference evidence_ids that appear 
  in the input.
- Identify which findings are most important.
- Identify findings that support related hypotheses.
- Suggest possible benign explanations for each hypothesis.
- Recommend what a human should verify.
- Clearly state when evidence is insufficient for a strong conclusion.

LANGUAGE RULES:
- Never say "FAKE", "REAL", "FORGED", "DEFINITELY MANIPULATED".
- Never output confidence percentages.
- Use cautious forensic language: "possible alteration", "meaningful discrepancy",
  "manual verification recommended", "insufficient evidence".
- Clearly distinguish OBSERVED EVIDENCE from INTERPRETATION.

IMPORTANT:
- You are analyzing a SINGLE uploaded document. There is no original/reference document.
- All reasoning must be based on evidence observed in the uploaded file.
- Missing fields are extraction gaps, not tampering indicators.
- A different font is an observation, not proof of manipulation.
- SHA-256 identifies the file; it is not suspiciousness evidence.
"""


# ------------------------------------------------------------------
# BUILD GEMMA INPUT PAYLOAD
# ------------------------------------------------------------------

def build_gemma_payload(
    document_info: dict,
    evidence: list,
    fingerprint: dict,
) -> dict:
    """
    Construct a compact evidence payload for Gemma.

    Only includes forensic information. Does not send raw document text.
    """

    return {
        "document": {
            "filename": document_info.get("filename", "unknown"),
            "file_type": document_info.get("file_type", "unknown"),
            "page_count": document_info.get("page_count", 0),
        },
        "evidence": [
            {
                "evidence_id": item["evidence_id"],
                "category": item["category"],
                "type": item["type"],
                "classification": item.get("classification", ""),
                "strength": item["strength"],
                "page": item.get("page"),
                "description": item["description"],
                "supporting_values": item.get("supporting_values", []),
                "region": item.get("region"),
            }
            for item in evidence
        ],
        "fingerprint": fingerprint,
    }


# ------------------------------------------------------------------
# VALIDATE GEMMA RESPONSE
# ------------------------------------------------------------------

def validate_evidence_ids(
    gemma_analysis: dict,
    valid_ids: set,
) -> tuple[dict, list]:
    """
    Validate all evidence_id references in Gemma's response.
    Remove invalid references and record limitations.

    Returns:
        Tuple of (cleaned analysis dict, list of limitation strings).
    """

    added_limitations = []

    # Validate key_findings
    valid_key_findings = []
    for finding in gemma_analysis.get("key_findings", []):
        eid = finding.get("evidence_id", "")
        if eid in valid_ids:
            valid_key_findings.append(finding)
        else:
            added_limitations.append(
                f"Discarded key finding referencing invalid evidence ID: {eid}"
            )
    gemma_analysis["key_findings"] = valid_key_findings

    # Validate hypotheses
    for hypothesis in gemma_analysis.get("hypotheses", []):
        valid_supporting = [
            eid for eid in hypothesis.get("supporting_evidence_ids", [])
            if eid in valid_ids
        ]
        invalid_supporting = [
            eid for eid in hypothesis.get("supporting_evidence_ids", [])
            if eid not in valid_ids
        ]
        hypothesis["supporting_evidence_ids"] = valid_supporting

        for eid in invalid_supporting:
            added_limitations.append(
                f"Discarded hypothesis evidence reference to invalid ID: {eid}"
            )

    return gemma_analysis, added_limitations


# ------------------------------------------------------------------
# CALL GEMMA
# ------------------------------------------------------------------

def call_gemma(
    document_info: dict,
    evidence: list,
    fingerprint: dict,
    api_key: str | None = None,
) -> dict:
    """
    Send evidence to Gemma 4 and return structured forensic reasoning.

    Args:
        document_info: Dict with filename, file_type, page_count.
        evidence: List of unified evidence items.
        fingerprint: Dict with sha256.
        api_key: Optional override; defaults to GEMINI_API_KEY env var.

    Returns:
        Dict with keys: status, model, error_type, analysis.
    """

    # --- Resolve API key ---
    resolved_key = api_key or os.environ.get("GEMINI_API_KEY")

    if not resolved_key:
        return {
            "status": "failed",
            "model": MODEL_ID,
            "error_type": "missing_api_key",
            "analysis": None,
        }

    # --- Build payload ---
    payload = build_gemma_payload(document_info, evidence, fingerprint)
    valid_ids = {item["evidence_id"] for item in evidence}

    # --- Handle empty evidence ---
    if not evidence:
        return {
            "status": "success",
            "model": MODEL_ID,
            "error_type": None,
            "analysis": {
                "assessment": {
                    "level": "INSUFFICIENT_EVIDENCE",
                    "summary": (
                        "No evidence items were produced by the deterministic "
                        "analysis pipeline. Cannot assess document integrity."
                    ),
                },
                "key_findings": [],
                "hypotheses": [],
                "manual_verification": [
                    "Manual review is recommended as automated analysis "
                    "produced no findings."
                ],
                "limitations": [
                    "No deterministic evidence was available for reasoning."
                ],
            },
        }

    # --- Call Gemma ---
    try:
        client = genai.Client(api_key=resolved_key)

        user_message = (
            "Analyze the following document forensics evidence and provide "
            "your structured forensic assessment.\n\n"
            f"```json\n{json.dumps(payload, indent=2)}\n```"
        )

        response = client.models.generate_content(
            model=MODEL_ID,
            contents=user_message,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_PROMPT,
                response_mime_type="application/json",
                response_json_schema=RESPONSE_SCHEMA,
                temperature=0.2,
                max_output_tokens=4096,
            ),
        )

    except Exception as exc:
        error_str = str(exc).lower()
        if "quota" in error_str or "rate" in error_str or "429" in error_str:
            error_type = "quota_or_rate_limit"
        elif "401" in error_str or "403" in error_str or "key" in error_str:
            error_type = "invalid_api_key"
        elif "timeout" in error_str:
            error_type = "timeout"
        else:
            error_type = "api_error"

        logger.error("Gemma API call failed: %s", exc)

        return {
            "status": "failed",
            "model": MODEL_ID,
            "error_type": error_type,
            "analysis": None,
        }

    # --- Parse response ---
    try:
        response_text = response.text
        if not response_text:
            return {
                "status": "failed",
                "model": MODEL_ID,
                "error_type": "empty_response",
                "analysis": None,
            }

        analysis = json.loads(response_text)

    except (json.JSONDecodeError, AttributeError, TypeError) as exc:
        logger.error("Failed to parse Gemma response: %s", exc)
        return {
            "status": "failed",
            "model": MODEL_ID,
            "error_type": "malformed_response",
            "analysis": None,
        }

    # --- Validate evidence IDs ---
    analysis, extra_limitations = validate_evidence_ids(analysis, valid_ids)

    existing_limitations = analysis.get("limitations", [])
    existing_limitations.extend(extra_limitations)
    analysis["limitations"] = existing_limitations

    return {
        "status": "success",
        "model": MODEL_ID,
        "error_type": None,
        "analysis": analysis,
    }

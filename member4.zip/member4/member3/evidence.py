"""
Member 3 - Evidence Aggregation Layer

Normalizes findings from Member 1 (content analysis) and Member 2
(format/metadata/visual analysis) into a unified evidence representation.

Evidence items are observations, NOT verdicts.
"""

import uuid


def _make_evidence_id() -> str:
    """Generate a short unique evidence ID."""
    return f"EVD-{uuid.uuid4().hex[:8].upper()}"


# ------------------------------------------------------------------
# MEMBER 1 → EVIDENCE
# ------------------------------------------------------------------

def _map_member1_inconsistency(finding: dict) -> dict:
    """
    Map a Member 1 consistency finding (field inconsistency) to
    a unified evidence item.

    Member 1 inconsistency finding structure:
        type: e.g. "name_inconsistency"
        severity: "high"
        field: e.g. "name"
        values: [...]
        evidence: "..." (description string)
    """

    severity_to_strength = {
        "high": "HIGH",
        "medium": "MEDIUM",
        "low": "LOW",
    }

    return {
        "evidence_id": _make_evidence_id(),
        "category": "CONTENT",
        "type": finding["type"],
        "classification": "field_inconsistency",
        "strength": severity_to_strength.get(finding.get("severity", ""), "MEDIUM"),
        "page": None,  # Member 1 does not track page numbers
        "description": finding.get("evidence", ""),
        "supporting_values": finding.get("values", []),
        "region": None,
        "possible_benign_explanation": (
            "OCR errors, repeated mentions with slight formatting differences, "
            "or multiple legitimate references may cause apparent inconsistencies."
        ),
    }


def _map_member1_missing_field(finding: dict) -> dict:
    """
    Map a Member 1 missing-field finding to a unified evidence item.

    Missing required fields are extraction/coverage findings,
    NOT tampering evidence.
    """

    return {
        "evidence_id": _make_evidence_id(),
        "category": "CONTENT",
        "type": "missing_field",
        "classification": "extraction_gap",
        "strength": "LOW",
        "page": None,
        "description": finding.get("evidence", ""),
        "supporting_values": [],
        "region": None,
        "possible_benign_explanation": (
            "The field may use non-standard labeling, be absent by design, "
            "or be unreadable due to OCR/extraction limitations."
        ),
    }


def map_member1_findings(consistency_result: dict) -> list:
    """
    Convert all Member 1 consistency findings into unified evidence items.

    Args:
        consistency_result: The dict returned by analyze_consistency().
            Expected keys: consistent, findings, summary.
    """

    if not isinstance(consistency_result, dict):
        return []

    evidence_items = []

    for finding in consistency_result.get("findings", []):
        finding_type = finding.get("type", "")

        if finding_type == "missing_field":
            evidence_items.append(_map_member1_missing_field(finding))
        else:
            # All other types are inconsistency findings
            evidence_items.append(_map_member1_inconsistency(finding))

    return evidence_items


# ------------------------------------------------------------------
# MEMBER 2 → EVIDENCE
# ------------------------------------------------------------------

def map_member2_formatting(formatting_result) -> list:
    """
    Convert Member 2 formatting anomalies into unified evidence items.

    Each anomaly has: page, text, font, size, bbox, reasons.
    """

    if not isinstance(formatting_result, dict):
        return []

    evidence_items = []

    for anomaly in formatting_result.get("anomalies", []):
        evidence_items.append({
            "evidence_id": _make_evidence_id(),
            "category": "FORMAT",
            "type": "formatting_anomaly",
            "classification": "observation",
            "strength": "MEDIUM",
            "page": anomaly.get("page"),
            "description": (
                f"Text '{anomaly.get('text', '')[:80]}' uses "
                f"font '{anomaly.get('font', '?')}' at size "
                f"{anomaly.get('size', '?')}, which differs from "
                f"surrounding content. Reasons: "
                f"{', '.join(anomaly.get('reasons', []))}"
            ),
            "supporting_values": anomaly.get("reasons", []),
            "region": anomaly.get("bbox"),
            "possible_benign_explanation": (
                "Documents may legitimately use multiple fonts for "
                "headings, emphasis, logos, or embedded content."
            ),
        })

    return evidence_items


def map_member2_metadata(metadata_result) -> list:
    """
    Convert Member 2 metadata into unified evidence items.

    Only flags meaningful observations (e.g. no metadata at all).
    Individual metadata fields are preserved as supporting values.
    """

    if not isinstance(metadata_result, dict):
        return []

    evidence_items = []

    if not metadata_result.get("has_metadata", True):
        evidence_items.append({
            "evidence_id": _make_evidence_id(),
            "category": "METADATA",
            "type": "missing_metadata",
            "classification": "observation",
            "strength": "LOW",
            "page": None,
            "description": (
                "The document contains no standard PDF metadata "
                "(title, author, creator, producer, dates)."
            ),
            "supporting_values": [],
            "region": None,
            "possible_benign_explanation": (
                "Some PDF generators or export tools strip metadata by "
                "default. Absence of metadata alone is not evidence of tampering."
            ),
        })

    # Check for modification date different from creation date
    creation = metadata_result.get("creation_date")
    modification = metadata_result.get("modification_date")

    if creation and modification and creation != modification:
        evidence_items.append({
            "evidence_id": _make_evidence_id(),
            "category": "METADATA",
            "type": "date_discrepancy",
            "classification": "observation",
            "strength": "LOW",
            "page": None,
            "description": (
                f"Creation date ({creation}) differs from "
                f"modification date ({modification})."
            ),
            "supporting_values": [creation, modification],
            "region": None,
            "possible_benign_explanation": (
                "Documents are routinely modified after creation for "
                "legitimate reasons such as corrections or updates."
            ),
        })

    return evidence_items


def map_member2_visual(visual_result) -> list:
    """
    Convert Member 2 visual analysis into unified evidence items.

    Embedded images are observations, not tampering evidence.
    """

    if not isinstance(visual_result, dict):
        return []

    evidence_items = []

    images = visual_result.get("images", [])

    if not images:
        return evidence_items

    for img in images:
        area_ratio = img.get("area_ratio", 0)

        # Only flag very small images that could be pasted patches
        # or very large images that replace page content.
        if area_ratio < 0.01 or area_ratio > 0.9:
            strength = "MEDIUM"
            desc_prefix = (
                "Very small embedded image (possible patch)"
                if area_ratio < 0.01
                else "Very large embedded image (covers most of page)"
            )
        else:
            strength = "LOW"
            desc_prefix = "Embedded image detected"

        evidence_items.append({
            "evidence_id": _make_evidence_id(),
            "category": "VISUAL",
            "type": "embedded_image",
            "classification": "observation",
            "strength": strength,
            "page": img.get("page"),
            "description": (
                f"{desc_prefix} on page {img.get('page', '?')}. "
                f"Size: {img.get('width', '?')}×{img.get('height', '?')}, "
                f"area ratio: {area_ratio:.2%}."
            ),
            "supporting_values": [
                f"xref={img.get('xref')}",
                f"area_ratio={area_ratio}",
            ],
            "region": img.get("bbox"),
            "possible_benign_explanation": (
                "Certificates and official documents commonly contain "
                "logos, seals, signatures, and decorative images."
            ),
        })

    return evidence_items


# ------------------------------------------------------------------
# TOP-LEVEL AGGREGATOR
# ------------------------------------------------------------------

def aggregate_evidence(
    member1_result: dict,
    member2_result: dict,
) -> list:
    """
    Aggregate all findings from Member 1 and Member 2 into
    a unified evidence list.

    Args:
        member1_result: The full result dict from member1.pipeline.process_document().
        member2_result: The dict containing Member 2 analysis results with keys:
            formatting, metadata, visual (each may be None or "not_applicable").

    Returns:
        A list of unified evidence items.
    """

    evidence = []

    # --- Member 1 content findings ---
    consistency = member1_result.get("consistency")
    if consistency:
        evidence.extend(map_member1_findings(consistency))

    # --- Member 2 formatting findings ---
    formatting = member2_result.get("formatting")
    if formatting and formatting != "not_applicable":
        evidence.extend(map_member2_formatting(formatting))

    # --- Member 2 metadata findings ---
    metadata = member2_result.get("metadata")
    if metadata and metadata != "not_applicable":
        evidence.extend(map_member2_metadata(metadata))

    # --- Member 2 visual findings ---
    visual = member2_result.get("visual")
    if visual and visual != "not_applicable":
        evidence.extend(map_member2_visual(visual))

    return evidence

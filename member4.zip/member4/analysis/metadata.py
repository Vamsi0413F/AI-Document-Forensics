import os
import re
from datetime import datetime
from typing import Dict, Any, List, Optional
import fitz
from PIL import Image, ExifTags


SUSPICIOUS_PRODUCERS = [
    "photoshop", "canva", "gimp", "sejda", "pdfescape", "ilovepdf",
    "smallpdf", "coreldraw", "paint.net", "photopea", "pixlr", "affinity"
]

AUTHORITATIVE_PRODUCERS = [
    "distiller", "quartz", "microsoft", "reportlab", "latex", "acrobat", "cairo"
]


def parse_pdf_date(date_str: Optional[str]) -> Optional[datetime]:
    """Parse PDF date format like D:YYYYMMDDHHmmSS or ISO string."""
    if not date_str:
        return None
    try:
        clean = re.sub(r"[^0-9]", "", date_str)
        if len(clean) >= 14:
            return datetime.strptime(clean[:14], "%Y%m%d%H%M%S")
        elif len(clean) >= 8:
            return datetime.strptime(clean[:8], "%Y%m%d")
    except Exception:
        pass
    return None


def analyze_metadata(file_path: str) -> Dict[str, Any]:
    """
    Forensic analysis of document metadata.
    Inspects creator, producer, creation/modification timestamps, and anomalies.
    """
    ext = os.path.splitext(file_path)[1].lower()
    findings: List[Dict[str, Any]] = []
    checks_performed = 0
    raw_metadata: Dict[str, Any] = {}

    if ext == ".pdf":
        try:
            doc = fitz.open(file_path)
            meta = doc.metadata or {}
            raw_metadata = dict(meta)

            creator = str(meta.get("creator", "")).strip()
            producer = str(meta.get("producer", "")).strip()
            creation_str = meta.get("creationDate", "")
            mod_str = meta.get("modDate", "")
            author = str(meta.get("author", "")).strip()

            # Check 1: Producer / Creator software inspection
            checks_performed += 1
            combined_tools = f"{creator} {producer}".lower()
            suspicious_match = next((tool for tool in SUSPICIOUS_PRODUCERS if tool in combined_tools), None)
            if suspicious_match:
                findings.append({
                    "id_suffix": "META_EDIT_TOOL",
                    "severity": "HIGH" if "photoshop" in suspicious_match or "sejda" in suspicious_match else "MEDIUM",
                    "title": "Editing Software Signature Detected",
                    "page": 1,
                    "region": "Document Header / Metadata",
                    "description": f"Producer/Creator indicates editing software ('{suspicious_match.capitalize()}'): {producer or creator}. Legitimate official credentials rarely originate from graphic manipulation suites.",
                    "tool": suspicious_match
                })

            # Check 2: Modification date disparity
            checks_performed += 1
            c_date = parse_pdf_date(creation_str)
            m_date = parse_pdf_date(mod_str)
            if c_date and m_date:
                diff_seconds = (m_date - c_date).total_seconds()
                if diff_seconds > 86400 * 7:  # Modified > 7 days after creation
                    days = int(diff_seconds // 86400)
                    findings.append({
                        "id_suffix": "META_TIME_DISPARITY",
                        "severity": "MEDIUM",
                        "title": "Extended Timestamp Discrepancy",
                        "page": 1,
                        "region": "PDF Date Table",
                        "description": f"Document modification date is {days} days after creation date. (Created: {c_date.strftime('%Y-%m-%d')}, Modified: {m_date.strftime('%Y-%m-%d')}). Indicates post-issuance revision.",
                    })
                elif diff_seconds < -60:  # Mod date earlier than creation date (clock spoofing or re-saving anomaly)
                    findings.append({
                        "id_suffix": "META_ANACHRONISM",
                        "severity": "HIGH",
                        "title": "Chronological Inconsistency in Metadata",
                        "page": 1,
                        "region": "PDF Date Table",
                        "description": f"Modification timestamp ({m_date.strftime('%Y-%m-%d')}) precedes Creation timestamp ({c_date.strftime('%Y-%m-%d')}). Highly indicative of manual metadata tampering.",
                    })

            # Check 3: Missing standard metadata on official document
            checks_performed += 1
            if not creator and not producer and not creation_str:
                findings.append({
                    "id_suffix": "META_STRIPPED",
                    "severity": "LOW",
                    "title": "Stripped or Sanitized Metadata",
                    "page": 1,
                    "region": "Document Catalog",
                    "description": "Standard PDF metadata fields (Producer, Creator, Timestamps) are completely blank. Commonly observed after web compression or metadata scrubbing tools.",
                })

            # Check 4: Incremental update checks / revision trails
            checks_performed += 1
            if hasattr(doc, "has_xref_stream") and doc.is_repaired:
                findings.append({
                    "id_suffix": "META_REPAIRED_TRAIL",
                    "severity": "LOW",
                    "title": "PDF Cross-Reference Repair Detected",
                    "page": 1,
                    "region": "XREF Table",
                    "description": "PDF structure required repair on load, suggesting non-standard assembly or hex editing.",
                })

            doc.close()
        except Exception as e:
            findings.append({
                "id_suffix": "META_ERROR",
                "severity": "LOW",
                "title": "Metadata Extraction Incomplete",
                "page": 1,
                "region": "File Structure",
                "description": f"Partial metadata parsing failure: {str(e)}",
            })

    elif ext in {".jpg", ".jpeg", ".png"}:
        checks_performed += 2
        try:
            img = Image.open(file_path)
            exif = img.getexif()
            if exif:
                exif_dict = {}
                for tag_id, val in exif.items():
                    tag = ExifTags.TAGS.get(tag_id, str(tag_id))
                    exif_dict[tag] = str(val)
                raw_metadata = exif_dict

                software = exif_dict.get("Software", "").lower()
                for tool in SUSPICIOUS_PRODUCERS:
                    if tool in software:
                        findings.append({
                            "id_suffix": "IMG_EDIT_SOFTWARE",
                            "severity": "HIGH",
                            "title": "Image Editing Software Tag in EXIF",
                            "page": 1,
                            "region": "EXIF Header",
                            "description": f"Image EXIF Software tag identifies '{tool.capitalize()}' ({software}).",
                        })
            else:
                raw_metadata = {"status": "No EXIF found (stripped or web-saved)"}
        except Exception as e:
            raw_metadata = {"error": str(e)}

    # Determine category severity
    if any(f["severity"] == "HIGH" for f in findings):
        cat_severity = "HIGH"
    elif any(f["severity"] == "MEDIUM" for f in findings):
        cat_severity = "ELEVATED"
    elif findings:
        cat_severity = "LOW"
    else:
        cat_severity = "CLEAN"

    return {
        "category": "metadata",
        "severity": cat_severity,
        "findings_count": len(findings),
        "checks_performed": max(checks_performed, 2),
        "checks_total": 3,
        "findings": findings,
        "raw_metadata": raw_metadata,
    }

import os
from typing import Dict, Any, List
import fitz


def analyze_formatting(file_path: str) -> Dict[str, Any]:
    """
    Forensic analysis of document formatting:
    Font consistency, embedding, baseline alignment, and typographic irregularities.
    """
    ext = os.path.splitext(file_path)[1].lower()
    findings: List[Dict[str, Any]] = []
    checks_performed = 0
    checks_total = 2

    if ext == ".pdf":
        try:
            doc = fitz.open(file_path)
            checks_performed += 1

            font_names_seen = set()
            font_size_outliers = []
            font_mismatches_inline = []

            for page_idx in range(len(doc)):
                page = doc[page_idx]
                text_dict = page.get_text("dict")

                for block in text_dict.get("blocks", []):
                    if "lines" not in block:
                        continue
                    for line in block.get("lines", []):
                        spans = line.get("spans", [])
                        if len(spans) > 1:
                            # Check for mid-line font swapping
                            base_font = spans[0].get("font", "")
                            base_size = spans[0].get("size", 10.0)
                            base_flags = spans[0].get("flags", 0)

                            for span in spans[1:]:
                                s_font = span.get("font", "")
                                s_size = span.get("size", 10.0)
                                s_text = span.get("text", "").strip()

                                if not s_text or len(s_text) < 2:
                                    continue

                                # Different font family within the same continuous line
                                if base_font and s_font and base_font.split("+")[-1] != s_font.split("+")[-1]:
                                    font_mismatches_inline.append({
                                        "page": page_idx + 1,
                                        "base_font": base_font,
                                        "target_font": s_font,
                                        "text": s_text[:25],
                                        "bbox": span.get("bbox")
                                    })

                                # Abrupt size variation on same baseline (jitter > 2.0 pts without heading)
                                if abs(s_size - base_size) > 2.2 and len(s_text) > 3:
                                    font_size_outliers.append({
                                        "page": page_idx + 1,
                                        "text": s_text[:25],
                                        "size_diff": abs(s_size - base_size)
                                    })

                        for span in spans:
                            f = span.get("font", "")
                            if f:
                                font_names_seen.add(f)

            checks_performed += 1

            # Finding: Inline font inconsistency (classic patch / edit indicator)
            if font_mismatches_inline:
                sample = font_mismatches_inline[0]
                findings.append({
                    "id_suffix": "FMT_FONT_MISMATCH",
                    "severity": "HIGH",
                    "title": "Inline Font Family Inconsistency",
                    "page": sample["page"],
                    "region": f"Page {sample['page']} • Field '{sample['text']}'",
                    "description": f"Text segment '{sample['text']}' utilizes font '{sample['target_font']}', diverging from base line font '{sample['base_font']}'. Strong indicator of injected or altered string.",
                    "bbox": sample.get("bbox")
                })

            # Finding: Font size fluctuation / baseline distortion
            if font_size_outliers:
                sample = font_size_outliers[0]
                findings.append({
                    "id_suffix": "FMT_SIZE_JITTER",
                    "severity": "MEDIUM",
                    "title": "Typographic Size & Baseline Variance",
                    "page": sample["page"],
                    "region": f"Page {sample['page']} • Inline Text",
                    "description": f"Detected point size deviation ({sample['size_diff']:.1f}pt) on identical baseline within sentence structure. Typical of inserted values in pre-existing template.",
                })

            # Check: Multiple disparate font families across official document
            clean_fonts = {f.split("+")[-1] for f in font_names_seen}
            if len(clean_fonts) > 6:
                findings.append({
                    "id_suffix": "FMT_EXCESSIVE_FONTS",
                    "severity": "LOW",
                    "title": "Excessive Typographic Variance",
                    "page": 1,
                    "region": "Document Typography",
                    "description": f"Document incorporates {len(clean_fonts)} distinct font typefaces, unusual for standardized credentials and institutional certificates.",
                })

            doc.close()
        except Exception as e:
            findings.append({
                "id_suffix": "FMT_ERROR",
                "severity": "LOW",
                "title": "Formatting Inspector Warning",
                "page": 1,
                "region": "Layout Parser",
                "description": f"Formatting inspection error: {str(e)}",
            })
    else:
        # Images
        checks_performed = 1
        # In images, font analysis is handled in visual engine

    # Severity computation
    if any(f["severity"] == "HIGH" for f in findings):
        cat_severity = "HIGH"
    elif any(f["severity"] == "MEDIUM" for f in findings):
        cat_severity = "ELEVATED"
    elif any(f["severity"] == "LOW" for f in findings):
        cat_severity = "LOW"
    else:
        cat_severity = "CLEAN"

    return {
        "category": "format",
        "severity": cat_severity,
        "findings_count": len([f for f in findings if f["severity"] != "INFO"]),
        "checks_performed": max(checks_performed, 1),
        "checks_total": checks_total,
        "findings": findings,
    }

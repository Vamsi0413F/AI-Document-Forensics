import os
import io
import cv2
import numpy as np
from PIL import Image, ImageChops, ImageEnhance
from typing import Dict, Any, List, Tuple
import fitz
from utils.file_handler import extract_document_pages_as_images


def compute_ela_difference(image: Image.Image, quality: int = 90) -> Tuple[Image.Image, float, np.ndarray]:
    """
    Computes Error Level Analysis (ELA).
    Resaves image at specific JPEG quality, then calculates amplified absolute difference.
    """
    rgb_img = image.convert("RGB")
    buffer = io.BytesIO()
    rgb_img.save(buffer, "JPEG", quality=quality)
    buffer.seek(0)
    resaved_img = Image.open(buffer)

    diff = ImageChops.difference(rgb_img, resaved_img)
    extrema = diff.getextrema()
    max_diff = max([ex[1] for ex in extrema]) if extrema else 1
    scale = 255.0 / max(max_diff, 1)

    enhancer = ImageEnhance.Brightness(diff)
    ela_enhanced = enhancer.enhance(min(scale, 15.0))

    diff_np = np.array(diff)
    mean_err = float(np.mean(diff_np))
    return ela_enhanced, mean_err, diff_np


def detect_suspicious_visual_regions(image: Image.Image, page_num: int = 1) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    Detects visual anomalies like spliced regions, sharp contrast borders,
    or localized compression anomalies using OpenCV & ELA.
    """
    findings: List[Dict[str, Any]] = []
    regions: List[Dict[str, Any]] = []

    width, height = image.size
    rgb_img = image.convert("RGB")
    np_img = np.array(rgb_img)

    # 1. ELA Analysis
    _, mean_err, diff_np = compute_ela_difference(image, quality=90)
    gray_diff = cv2.cvtColor(diff_np, cv2.COLOR_RGB2GRAY)
    blurred_diff = cv2.GaussianBlur(gray_diff, (11, 11), 0)

    # Threshold for local ELA peaks
    mean_val = np.mean(blurred_diff)
    std_val = np.std(blurred_diff)

    if std_val > 1.2:  # Lowered threshold to be sensitive to inserted compressed raster stamps
        thresh_val = mean_val + 2.0 * std_val
        _, mask = cv2.threshold(blurred_diff, max(int(thresh_val), 14), 255, cv2.THRESH_BINARY)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        region_labels = ["Region A", "Region B", "Region C"]
        reg_idx = 0

        for cnt in contours:
            area = cv2.contourArea(cnt)
            if 600 < area < (width * height * 0.3):
                x, y, w, h = cv2.boundingRect(cnt)
                # Ignore full borders
                if w > width * 0.75 or h > height * 0.75:
                    continue

                label = region_labels[reg_idx] if reg_idx < len(region_labels) else f"Region {reg_idx+1}"
                reg_idx += 1

                severity = "HIGH" if area > 2000 else "ELEVATED"
                regions.append({
                    "id": label,
                    "page": page_num,
                    "x": int(x),
                    "y": int(y),
                    "width": int(w),
                    "height": int(h),
                    "severity": severity,
                    "reason": "Localized compression artifact variance (ELA divergence)",
                })
                if reg_idx >= 3:
                    break

    # Build findings from detected regions
    if regions:
        high_regs = [r for r in regions if r["severity"] == "HIGH"]
        if high_regs:
            findings.append({
                "id_suffix": "VIS_COMPRESSION_ANOMALY",
                "severity": "HIGH",
                "title": "Compression Artifact Discontinuity (ELA)",
                "page": page_num,
                "region": f"Page {page_num} • {high_regs[0]['id']}",
                "description": f"Error Level Analysis identified abnormal JPEG quantization in {high_regs[0]['id']} ([{high_regs[0]['x']}, {high_regs[0]['y']}]). Diverges from the background noise floor, characteristic of a spliced or pasted digital element.",
            })
        elevated_regs = [r for r in regions if r["severity"] in ["MEDIUM", "ELEVATED"]]
        if elevated_regs:
            findings.append({
                "id_suffix": "VIS_PATCH_EDGE",
                "severity": "ELEVATED",
                "title": "Abrupt Boundary Contrast / Splicing Border",
                "page": page_num,
                "region": f"Page {page_num} • {elevated_regs[0]['id']}",
                "description": f"Sharp rectangular edge gradients detected around {elevated_regs[0]['id']}. Consistent with bounding box artifacts from visual pasting or digital collage.",
            })

    return findings, regions


def analyze_visual(file_path: str) -> Dict[str, Any]:
    """
    Forensic visual analysis covering ELA, embedded raster image inspections,
    and suspicious bounding box extraction.
    """
    ext = os.path.splitext(file_path)[1].lower()
    findings: List[Dict[str, Any]] = []
    all_regions: List[Dict[str, Any]] = []
    checks_performed = 2
    checks_total = 2

    # If PDF, also inspect embedded raster objects and extract exact coordinates
    if ext == ".pdf":
        try:
            doc = fitz.open(file_path)
            reg_idx = 1
            for p_idx in range(len(doc)):
                page = doc[p_idx]
                img_list = page.get_images(full=True)
                for img_info in img_list:
                    xref = img_info[0]
                    rects = page.get_image_rects(xref)
                    for r in rects:
                        # If embedded image is a small/medium badge, stamp, or signature
                        # (not a full background page)
                        if 30 < r.width < page.rect.width * 0.6 and 30 < r.height < page.rect.height * 0.6:
                            # Check if the PDF has editing metadata or if image is JPEG with compression
                            # Extract image bytes and check
                            try:
                                base_img = doc.extract_image(xref)
                                img_ext = base_img.get("ext", "")
                                # If document has Photoshop or Canva or this is a spliced badge
                                meta = doc.metadata or {}
                                prod = f"{meta.get('producer', '')} {meta.get('creator', '')}".lower()
                                is_suspicious_prod = any(t in prod for t in ["photoshop", "canva", "gimp", "sejda"])

                                if is_suspicious_prod or img_ext in ["jpeg", "jpg"]:
                                    reg_label = f"Region {chr(64 + reg_idx)}"
                                    reg_idx += 1
                                    sev = "HIGH" if "photoshop" in prod else "ELEVATED"
                                    # Scale coordinates to 150 DPI pixel equivalent (approx 150/72 = 2.08)
                                    scale = 150.0 / 72.0
                                    all_regions.append({
                                        "id": reg_label,
                                        "page": p_idx + 1,
                                        "x": int(r.x0 * scale),
                                        "y": int(r.y0 * scale),
                                        "width": int(r.width * scale),
                                        "height": int(r.height * scale),
                                        "severity": sev,
                                        "reason": f"Embedded raster element ({img_ext.upper()}) inserted into vector layout",
                                    })
                            except Exception:
                                pass
            doc.close()
        except Exception:
            pass

    # Page-level ELA and contour detection
    try:
        pages = extract_document_pages_as_images(file_path, max_pages=3)
        for idx, page_img in enumerate(pages):
            p_findings, p_regions = detect_suspicious_visual_regions(page_img, page_num=idx + 1)
            findings.extend(p_findings)
            # Merge regions if not duplicate
            for pr in p_regions:
                if not any(r["page"] == pr["page"] and abs(r["x"] - pr["x"]) < 40 for r in all_regions):
                    all_regions.append(pr)
    except Exception as e:
        findings.append({
            "id_suffix": "VIS_ERROR",
            "severity": "LOW",
            "title": "Visual Analysis Module Fallback",
            "page": 1,
            "region": "Image Pipeline",
            "description": f"Visual processing note: {str(e)}",
        })

    # If regions exist from embedded image inspect but no finding was added yet
    if all_regions and not findings:
        high_regs = [r for r in all_regions if r["severity"] == "HIGH"]
        if high_regs:
            findings.append({
                "id_suffix": "VIS_EMBEDDED_PATCH",
                "severity": "HIGH",
                "title": "Spliced Raster Badge / Overlay",
                "page": high_regs[0]["page"],
                "region": f"Page {high_regs[0]['page']} • {high_regs[0]['id']}",
                "description": f"Identified distinct raster object {high_regs[0]['id']} with compression disparity inserted into vector credential layout.",
            })
        else:
            findings.append({
                "id_suffix": "VIS_EMBEDDED_PATCH",
                "severity": "ELEVATED",
                "title": "Suspicious Visual Element Boundary",
                "page": all_regions[0]["page"],
                "region": f"Page {all_regions[0]['page']} • {all_regions[0]['id']}",
                "description": f"Visual boundary detected at {all_regions[0]['id']} requiring magnification review.",
            })

    # Severity computation
    if any(f["severity"] == "HIGH" for f in findings):
        cat_severity = "HIGH"
    elif any(f["severity"] in ["MEDIUM", "ELEVATED"] for f in findings):
        cat_severity = "ELEVATED"
    elif any(f["severity"] == "LOW" for f in findings):
        cat_severity = "LOW"
    else:
        cat_severity = "CLEAN"

    return {
        "category": "visual",
        "severity": cat_severity,
        "findings_count": len(findings),
        "checks_performed": checks_performed,
        "checks_total": checks_total,
        "findings": findings,
        "regions": all_regions,
    }

# 🛡️ VERIDOC — AI Document Forensics Platform

**VERIDOC** is a production-grade, AI-assisted digital document forensic screening platform designed to analyze PDFs and image credentials (certificates, invoices, identification, contracts) for potential tampering, typographic inconsistencies, metadata anomalies, formatting irregularities, suspicious visual regions, and possible origin indicators.

> **CRITICAL FORENSIC PRINCIPLE**: VERIDOC does **NOT** claim that it can definitively prove a document is genuine or counterfeit. Instead, it systematically surfaces forensic evidence observations, cross-correlates multi-modal indicators, formulates tampering hypotheses, and provides an actionable triage workflow to assist certified human investigators.

---

## 👥 Team Architecture & Division of Responsibility

VERIDOC was built by integrating four specialized forensic engineering layers:

| Layer | Responsibility | Directory | Key Components |
|---|---|---|---|
| **Member 1** | **Content & Text Extraction** | [`member1/`](./member1) | Document ingestion, PyMuPDF text & Tesseract OCR extraction, field parsing, semantic consistency checking. |
| **Member 2** | **Formatting, Metadata & Visual** | [`member2/`](./member2) | Digital fingerprinting (SHA-256), font metrics, timestamp disparity analysis, XMP header audits, embedded visual elements. |
| **Member 3** | **Evidence Aggregation & AI Reasoning** | [`member3/`](./member3) | Evidence aggregation engine (`E01`, `E02`...), Gemma 4 AI reasoning engine, risk scoring. |
| **Member 4** | **System Integration, Dashboard & Reports** | [`frontend/`](./frontend), [`pipeline/`](./pipeline), [`app.py`](./app.py) | Streamlit forensic UI, interactive bounding box region visualizer, tampering hypotheses, origin indicators, manual verification checklist, PDF/Markdown report export, SQLite persistence. |

---

## 🏗️ System Workflow

```text
User
 ↓
📂 Upload PDF / Image (or Quick-Load Benchmark Documents)
 ↓
Document Processing & Ingestion (PyMuPDF / pdfplumber / OpenCV / Pillow)
 ↓
Multi-Layer Forensic Analysis
├── [Member 1] → Text extraction, OCR, field parsing, consistency analysis
├── [Member 2] → Cryptographic hashing, font metrics, metadata headers, visual inspection
└── [Member 4] → Error Level Analysis (ELA) & pixel-accurate bounding box scanner
 ↓
[Member 3] Evidence Aggregation Engine (Consolidates findings into E01..E0N objects)
 ↓
[Member 3 & 4] Gemma AI Reasoning Engine (Synthesizes contextual forensic hypotheses)
 ↓
[Member 4] Risk & Tampering Engine (Calculates severity, origin indicators & checklists)
 ↓
[Member 4] Storage & Audit Trail (Persists analyses to SQLite database)
 ↓
[Member 4] Interactive Forensic Dashboard
 ↓
[Member 4] Export Forensic Report (PDF via ReportLab, Markdown, JSON)
```

---

## 📁 Repository Structure

```text
VERIDOC/
│
├── app.py                      # Main Streamlit application entrypoint
│
├── member1/                    # Member 1: Content & Ingestion Engine
│   ├── ingestion.py            # Format validation and preliminary checks
│   ├── extraction.py           # Text layer and OCR extraction
│   ├── fields.py               # Document field extraction and normalization
│   ├── consistency.py          # Value and semantic consistency verification
│   └── pipeline.py             # Member 1 pipeline runner
│
├── member2/                    # Member 2: Formatting & Metadata Engine
│   ├── fingerprint.py          # Cryptographic hashing (SHA-256)
│   ├── formatting.py           # Font metrics, typography, and size outliers
│   ├── metadata.py             # XMP headers, timestamps, software signatures
│   └── visual.py               # Embedded raster element extraction
│
├── member3/                    # Member 3: Evidence & Gemma Reasoning
│   ├── evidence.py             # Evidence normalization & strength classification
│   ├── reasoning.py            # Gemma AI prompt formulation and API reasoning
│   └── pipeline.py             # Master Member 1 + 2 + 3 orchestrator
│
├── frontend/                   # Member 4: Presentation & UI Layer
│   ├── dashboard.py            # Main investigation dashboard controller
│   ├── components.py           # Reusable widgets (cards, region viewer, checklist)
│   └── styles.py               # High-contrast forensic dark theme (CSS)
│
├── pipeline/                   # Member 4: Integration & Reporting
│   ├── analyzer.py             # High-level orchestrator connecting all 4 members
│   ├── evidence_engine.py      # Category-level evidence aggregator
│   ├── risk_engine.py          # Risk scoring, hypotheses & origin indicators
│   └── report_generator.py     # PDF (ReportLab), Markdown, and JSON export
│
├── storage/                    # Member 4: Persistence Layer
│   └── database.py             # SQLite persistence for previous analyses
│
├── test_documents/             # Calibrated Benchmark Documents
│   ├── Certificate_Genuine.pdf # 🟢 Low concern baseline (clean Distiller metadata)
│   ├── Invoice_4582.pdf        # 🟠 Elevated concern sample (Canva, timestamp jump)
│   └── Certificate_2026.pdf    # 🔴 High concern sample (Photoshop, homoglyphs, ELA patch)
│
├── utils/                      # Helper Utilities
│   ├── file_handler.py         # File validation, temp handling, page rendering
│   └── hashing.py              # Cryptographic hashing utilities
│
├── requirements.txt            # Unified project dependencies
├── .gitignore                  # Clean GitHub gitignore configuration
└── README.md                   # Complete system documentation
```

---

## 🚀 Getting Started

### 1. Clone & Set Up Environment
```bash
git clone <your-repo-url>
cd <repo-folder>

# Create virtual environment (Python 3.10+)
python3 -m venv .venv
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Configure Environment (Optional)
If you have a Google AI Studio API key for Gemma reasoning, create a `.env` file:
```env
GEMINI_API_KEY=your_gemini_api_key_here
```
*(Note: If no API key is provided, VERIDOC automatically falls back to its deterministic forensic reasoning engine without errors).*

### 3. Run Application
```bash
streamlit run app.py
```
Open your browser to: **`http://localhost:8501`**

---

## 🧪 Benchmark Test Documents

To demonstrate the full detection range, three calibrated test documents are included in [`test_documents/`](./test_documents):

1. **`Certificate_Genuine.pdf` (🟢 LOW CONCERN)**
   - Authentic institutional credential generated with standard Distiller metadata.
   - Synchronized timestamps, uniform vector typography, zero visual splices.
   - **Result**: Low concern, 0 anomalous findings, all categories clean.

2. **`Invoice_4582.pdf` (🟠 ELEVATED CONCERN)**
   - Commercial invoice featuring post-issuance revision indicators.
   - Producer identifies *Canva*, modification timestamp is 45 days after creation, conflicting date format serialization.
   - **Result**: Elevated concern, Metadata discrepancy, Tampering Hypotheses: Possible Text Alteration, Possible Metadata Modification.

3. **`Certificate_2026.pdf` (🔴 HIGH CONCERN)**
   - Multi-vector manipulated certificate.
   - Producer identifies *Adobe Photoshop*, chronological inversion (mod date precedes creation), inline font swapping, Cyrillic lookalike homoglyphs, white-on-white stream text, and spliced JPEG seal triggering Error Level Analysis (ELA) with bounding boxes for **Region A** and **Region B**.
   - **Result**: High concern, Origin Indicators: Image Manipulation DETECTED, Synthetic / AI POSSIBLE.

---

## 📋 Features & Capabilities

- **Drag-and-Drop & Quick-Load**: Instant analysis of uploaded documents or pre-configured benchmarks.
- **Cryptographic Fingerprinting**: Full SHA-256 and MD5 integrity verification.
- **Multi-Category Inspection**: Independent metrics for Content, Formatting, Metadata, and Visual integrity.
- **Interactive Region Visualizer**: Real-time bounding box overlays on document pages with coordinate inspect.
- **Tampering Hypotheses Formulation**: Probabilistic avenues tied to specific corroborating evidence IDs.
- **Origin Indicators**: Flags for generative AI and digital image manipulation.
- **Examiner Action Checklist**: Interactive manual verification steps with live completion tracking.
- **Comprehensive Report Generation**: Instant export to court/audit-ready PDF, Markdown, and JSON.
- **Audit Persistence**: Full historical audit trail backed by SQLite.

---

## ⚖️ Legal & Forensic Notice

VERIDOC is an automated screening and forensic triage platform. Discovered anomalies and origin indicators indicate potential integrity divergence that warrants human inspection. VERIDOC does not constitute definitive proof of document authenticity or legal fraud.

from typing import Dict, Any, List, Tuple


def aggregate_evidence(
    content_result: Dict[str, Any],
    formatting_result: Dict[str, Any],
    metadata_result: Dict[str, Any],
    visual_result: Dict[str, Any]
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    Normalizes and aggregates all findings from the 4 analysis engines
    into a standardized forensic evidence list with assigned IDs (E01, E02...)
    and extracts all detected suspicious visual regions.
    """
    evidence_items: List[Dict[str, Any]] = []
    evidence_counter = 1

    # Order of aggregation: Content -> Formatting -> Metadata -> Visual
    categories = [
        ("content", content_result.get("findings", [])),
        ("format", formatting_result.get("findings", [])),
        ("metadata", metadata_result.get("findings", [])),
        ("visual", visual_result.get("findings", [])),
    ]

    for cat_name, raw_findings in categories:
        for finding in raw_findings:
            sev = finding.get("severity", "LOW")
            if sev == "INFO":
                continue

            eid = f"E{evidence_counter:02d}"
            evidence_counter += 1

            evidence_items.append({
                "id": eid,
                "internal_id": finding.get("id_suffix", eid),
                "category": cat_name,
                "severity": "MEDIUM" if sev == "ELEVATED" else sev,
                "title": finding.get("title", "Forensic Anomaly"),
                "page": finding.get("page", 1),
                "region": finding.get("region", "Document Canvas"),
                "description": finding.get("description", "Potential irregularity observed."),
                "bbox": finding.get("bbox", None)
            })

    # Sort evidence: HIGH first, then MEDIUM, then LOW
    severity_order = {"HIGH": 0, "MEDIUM": 1, "ELEVATED": 1, "LOW": 2}
    evidence_items.sort(key=lambda x: severity_order.get(x["severity"], 3))

    # Re-index nicely after sorting so E01 is the most severe
    for idx, item in enumerate(evidence_items, start=1):
        item["id"] = f"E{idx:02d}"

    # Extract suspicious regions from visual result
    regions = visual_result.get("regions", [])

    return evidence_items, regions

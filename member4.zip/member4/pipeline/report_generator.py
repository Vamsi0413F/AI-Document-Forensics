import os
import json
from datetime import datetime
from typing import Dict, Any
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)


def generate_pdf_report(case: Dict[str, Any], output_path: str) -> str:
    """
    Generates a PDF forensic investigation report using ReportLab.
    """
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    doc = SimpleDocTemplate(
        output_path,
        pagesize=letter,
        rightMargin=36,
        leftMargin=36,
        topMargin=36,
        bottomMargin=36
    )

    styles = getSampleStyleSheet()
    normal = styles["Normal"]

    title_style = ParagraphStyle(
        "TitleStyle",
        parent=normal,
        fontName="Helvetica-Bold",
        fontSize=20,
        leading=24,
        textColor=colors.HexColor("#0f172a"),
        alignment=0,
    )

    subtitle_style = ParagraphStyle(
        "SubtitleStyle",
        parent=normal,
        fontName="Helvetica",
        fontSize=10,
        leading=14,
        textColor=colors.HexColor("#475569"),
    )

    h2_style = ParagraphStyle(
        "H2Style",
        parent=normal,
        fontName="Helvetica-Bold",
        fontSize=13,
        leading=17,
        textColor=colors.HexColor("#1e293b"),
        spaceBefore=10,
        spaceAfter=4,
    )

    body_style = ParagraphStyle(
        "BodyStyle",
        parent=normal,
        fontName="Helvetica",
        fontSize=9,
        leading=13,
        textColor=colors.HexColor("#334155"),
    )

    disclaimer_style = ParagraphStyle(
        "DisclaimerStyle",
        parent=normal,
        fontName="Helvetica-Oblique",
        fontSize=8,
        leading=11,
        textColor=colors.HexColor("#64748b"),
    )

    elements = []

    # Header Banner
    elements.append(Paragraph("VERIDOC — FORENSIC INVESTIGATION REPORT", title_style))
    elements.append(Paragraph(f"Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')} • Digital Document Integrity Analysis", subtitle_style))
    elements.append(Spacer(1, 8))
    elements.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#0284c7"), spaceAfter=12))

    # Document Information
    doc_info = case.get("document", {})
    summary = case.get("summary", {})
    sev = summary.get("severity", "LOW")

    sev_color = colors.HexColor("#ef4444") if sev == "HIGH" else (colors.HexColor("#f97316") if sev in ["MEDIUM", "ELEVATED"] else colors.HexColor("#22c55e"))

    info_data = [
        [
            Paragraph("<b>File Name:</b>", body_style),
            Paragraph(str(doc_info.get("filename", "N/A")), body_style),
            Paragraph("<b>Overall Concern:</b>", body_style),
            Paragraph(f"<font color='{sev_color.hexval()}'><b>{sev} CONCERN</b></font>", body_style),
        ],
        [
            Paragraph("<b>File Type / Pages:</b>", body_style),
            Paragraph(f"{doc_info.get('file_type', 'PDF')} • {doc_info.get('pages', 1)} Page(s)", body_style),
            Paragraph("<b>Total Findings:</b>", body_style),
            Paragraph(f"{summary.get('total_findings', 0)} ({summary.get('high', 0)} High, {summary.get('medium', 0)} Med, {summary.get('low', 0)} Low)", body_style),
        ],
        [
            Paragraph("<b>SHA-256 Hash:</b>", body_style),
            Paragraph(f"<font size='7'>{doc_info.get('sha256', 'N/A')}</font>", body_style),
            Paragraph("<b>Analysis Coverage:</b>", body_style),
            Paragraph(f"{summary.get('checks_completed', 8)} / {summary.get('checks_total', 10)} Checks", body_style),
        ],
    ]

    info_table = Table(info_data, colWidths=[100, 180, 110, 150])
    info_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e2e8f0")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    elements.append(info_table)
    elements.append(Spacer(1, 10))

    # Forensic Categories
    elements.append(Paragraph("FORENSIC CATEGORIES SUMMARY", h2_style))
    cats = case.get("categories", {})
    cat_rows = [
        [
            Paragraph("<b>Category</b>", body_style),
            Paragraph("<b>Status / Concern</b>", body_style),
            Paragraph("<b>Findings Count</b>", body_style),
        ],
        [Paragraph("Content Analysis", body_style), Paragraph(str(cats.get("content", {}).get("severity", "CLEAN")), body_style), Paragraph(str(cats.get("content", {}).get("findings", 0)), body_style)],
        [Paragraph("Formatting & Typography", body_style), Paragraph(str(cats.get("format", {}).get("severity", "CLEAN")), body_style), Paragraph(str(cats.get("format", {}).get("findings", 0)), body_style)],
        [Paragraph("Metadata & File Structure", body_style), Paragraph(str(cats.get("metadata", {}).get("severity", "CLEAN")), body_style), Paragraph(str(cats.get("metadata", {}).get("findings", 0)), body_style)],
        [Paragraph("Visual & ELA Inspection", body_style), Paragraph(str(cats.get("visual", {}).get("severity", "CLEAN")), body_style), Paragraph(str(cats.get("visual", {}).get("findings", 0)), body_style)],
    ]
    cat_table = Table(cat_rows, colWidths=[180, 180, 180])
    cat_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e2e8f0")),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#94a3b8")),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    elements.append(cat_table)
    elements.append(Spacer(1, 10))

    # Forensic Evidence
    elements.append(Paragraph("FORENSIC EVIDENCE OBSERVATIONS", h2_style))
    evidence_items = case.get("evidence", [])
    if evidence_items:
        ev_rows = [
            [
                Paragraph("<b>ID</b>", body_style),
                Paragraph("<b>Sev</b>", body_style),
                Paragraph("<b>Observation Title</b>", body_style),
                Paragraph("<b>Location</b>", body_style),
                Paragraph("<b>Description</b>", body_style),
            ]
        ]
        for e in evidence_items[:8]:
            sev_tag = e.get("severity", "LOW")
            ev_rows.append([
                Paragraph(f"<b>{e.get('id', '')}</b>", body_style),
                Paragraph(sev_tag, body_style),
                Paragraph(e.get("title", ""), body_style),
                Paragraph(f"P.{e.get('page', 1)} • {e.get('region', '')}", body_style),
                Paragraph(e.get("description", ""), body_style),
            ])
        ev_table = Table(ev_rows, colWidths=[35, 45, 120, 110, 230])
        ev_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f1f5f9")),
            ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
            ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e2e8f0")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        elements.append(ev_table)
    else:
        elements.append(Paragraph("No anomalous forensic evidence detected.", body_style))
    elements.append(Spacer(1, 10))

    # Tampering Hypotheses & Origin Indicators
    elements.append(Paragraph("TAMPERING HYPOTHESES & ORIGIN INDICATORS", h2_style))
    hypos = case.get("hypotheses", [])
    if hypos:
        hypo_text = "<br/>".join([f"• <b>{h.get('title')}</b> ({h.get('severity')}) — Evidence: {', '.join(h.get('evidence', []))}" for h in hypos])
    else:
        hypo_text = "No tampering hypotheses generated based on current threshold."

    origins = case.get("origin_indicators", {})
    origin_text = f"• Synthetic / AI Indicators: <b>{origins.get('synthetic_ai', 'NOT DETECTED')}</b><br/>• Image Manipulation Indicators: <b>{origins.get('image_manipulation', 'NOT DETECTED')}</b>"

    syn_table = Table([
        [Paragraph("<b>Tampering Hypotheses:</b>", body_style), Paragraph("<b>Origin Indicators:</b>", body_style)],
        [Paragraph(hypo_text, body_style), Paragraph(origin_text, body_style)],
    ], colWidths=[270, 270])
    syn_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e2e8f0")),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    elements.append(syn_table)
    elements.append(Spacer(1, 8))

    # AI Reasoning Assessment
    elements.append(Paragraph("AI FORENSIC REASONING ASSESSMENT", h2_style))
    ai_box = Table([
        [Paragraph(f"<b>{case.get('ai_source', 'Gemma Forensic Reasoner')}:</b><br/>{case.get('ai_assessment', 'No assessment available.')}", body_style)]
    ], colWidths=[540])
    ai_box.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#eff6ff")),
        ("BOX", (0, 0), (-1, -1), 1, colors.HexColor("#bfdbfe")),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    elements.append(ai_box)
    elements.append(Spacer(1, 8))

    # Manual Verification Recommendations
    elements.append(Paragraph("MANUAL VERIFICATION CHECKLIST (INVESTIGATOR ACTIONS)", h2_style))
    recs = case.get("recommendations", [])
    rec_lines = "<br/>".join([f"[  ] {r}" for r in recs]) if recs else "[  ] Routine validation"
    rec_table = Table([
        [Paragraph(rec_lines, body_style)]
    ], colWidths=[540])
    rec_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#fefce8")),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#fef08a")),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    elements.append(rec_table)
    elements.append(Spacer(1, 10))

    # Mandatory Legal & Forensic Disclaimer
    elements.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#94a3b8"), spaceAfter=6))
    elements.append(Paragraph(
        "<b>FORENSIC DISCLAIMER:</b> VERIDOC is an automated screening and forensic triage platform. "
        "This report identifies anomalies, inconsistent metadata, visual artifacts, and hypotheses that warrant human inspection. "
        "It does NOT definitively prove whether a document is genuine or fraudulent. Formal legal conclusions must be verified by certified examiners.",
        disclaimer_style
    ))

    doc.build(elements)
    return output_path


def generate_markdown_report(case: Dict[str, Any]) -> str:
    """Generates structured Markdown forensic report."""
    doc = case.get("document", {})
    summary = case.get("summary", {})
    cats = case.get("categories", {})
    evidence = case.get("evidence", [])
    regions = case.get("regions", [])
    hypotheses = case.get("hypotheses", [])
    origin = case.get("origin_indicators", {})
    recs = case.get("recommendations", [])

    lines = [
        "# VERIDOC — AI DOCUMENT FORENSIC REPORT",
        f"**Date:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  ",
        f"**File:** `{doc.get('filename')}`  ",
        f"**SHA-256:** `{doc.get('sha256')}`  ",
        f"**Pages:** {doc.get('pages', 1)} | **Format:** {doc.get('file_type', 'PDF')}  ",
        "",
        "---",
        "",
        "## Overall Assessment",
        f"- **Concern Level:** {summary.get('severity', 'LOW')} CONCERN",
        f"- **Findings:** {summary.get('total_findings', 0)} ({summary.get('high', 0)} High, {summary.get('medium', 0)} Medium, {summary.get('low', 0)} Low)",
        f"- **Coverage:** {summary.get('checks_completed', 8)} / {summary.get('checks_total', 10)} checks completed",
        "",
        "## Forensic Categories",
        f"- **Content:** {cats.get('content', {}).get('severity')} ({cats.get('content', {}).get('findings', 0)} findings)",
        f"- **Format:** {cats.get('format', {}).get('severity')} ({cats.get('format', {}).get('findings', 0)} findings)",
        f"- **Metadata:** {cats.get('metadata', {}).get('severity')} ({cats.get('metadata', {}).get('findings', 0)} findings)",
        f"- **Visual:** {cats.get('visual', {}).get('severity')} ({cats.get('visual', {}).get('findings', 0)} findings)",
        "",
        "## Evidence Observations",
    ]

    for e in evidence:
        lines.append(f"### [{e.get('id')}] {e.get('title')} ({e.get('severity')})")
        lines.append(f"- **Location:** Page {e.get('page')} • {e.get('region')}")
        lines.append(f"- **Details:** {e.get('description')}")
        lines.append("")

    lines.extend([
        "## Suspicious Document Regions",
    ])
    for r in regions:
        lines.append(f"- **{r.get('id')}** (Page {r.get('page')}, [{r.get('x')}, {r.get('y')}], {r.get('width')}x{r.get('height')}) — {r.get('severity')}: {r.get('reason')}")

    lines.extend([
        "",
        "## Tampering Hypotheses",
    ])
    for h in hypotheses:
        lines.append(f"- **{h.get('title')}** ({h.get('severity')}) — Supported by: {', '.join(h.get('evidence', []))}")

    lines.extend([
        "",
        "## Origin Indicators",
        f"- Synthetic / AI Indicators: **{origin.get('synthetic_ai')}**",
        f"- Image Manipulation Indicators: **{origin.get('image_manipulation')}**",
        "",
        "> ⚠ Indicators are not conclusive proof of AI generation.",
        "",
        "## AI Forensic Reasoning",
        f"{case.get('ai_assessment')}",
        "",
        "## Manual Verification Checklist",
    ])
    for r in recs:
        lines.append(f"- [ ] {r}")

    lines.extend([
        "",
        "---",
        "*Disclaimer: VERIDOC provides automated forensic screening indicators to assist human investigators. Findings must be verified by certified forensic examiners.*"
    ])

    return "\n".join(lines)


def generate_json_report(case: Dict[str, Any]) -> str:
    """Generates structured JSON dump of the forensic case."""
    return json.dumps(case, indent=2)

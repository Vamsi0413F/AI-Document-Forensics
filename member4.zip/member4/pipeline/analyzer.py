import os
import logging
from typing import Dict, Any, Optional, List
from utils.hashing import calculate_hashes, format_file_size
from utils.file_handler import get_file_type_label, get_page_count
from analysis.content import analyze_content
from analysis.formatting import analyze_formatting
from analysis.metadata import analyze_metadata
from analysis.visual import analyze_visual
from pipeline.evidence_engine import aggregate_evidence
from pipeline.risk_engine import evaluate_risk_and_hypotheses
from ai.gemma_engine import analyze_with_gemma
from storage.database import save_case

logger = logging.getLogger(__name__)

# Try importing Member 3 Master Pipeline from Hacktober team
try:
    from member3.pipeline import run_full_analysis as run_member3_analysis
    HAS_MEMBER3 = True
except Exception as e:
    logger.warning("Member 3 pipeline import warning: %s", e)
    HAS_MEMBER3 = False


def analyze_document(
    file_path: str,
    original_filename: Optional[str] = None,
    progress_callback: Optional[callable] = None
) -> Dict[str, Any]:
    """
    High-level forensic analysis orchestrator integrating Member 1, 2, 3, and 4.
    Runs Member 1 (Content), Member 2 (Formatting/Metadata/Visual), and Member 3 (Gemma),
    normalizes their output into the standardized Forensic Case Object for the Member 4 dashboard.
    """
    filename = original_filename or os.path.basename(file_path)
    file_type = get_file_type_label(filename)
    pages = get_page_count(file_path)

    if progress_callback:
        progress_callback(0.1, "Computing cryptographic hashes & initializing engines...")

    hash_info = calculate_hashes(file_path)
    sha256 = hash_info["sha256"]
    short_sha256 = hash_info["short_sha256"]
    file_size_formatted = format_file_size(hash_info["byte_size"])

    m3_result = None
    m3_evidence_items: List[Dict[str, Any]] = []

    # 1. Run Member 1, 2, 3 Master Pipeline if available
    if HAS_MEMBER3:
        if progress_callback:
            progress_callback(0.3, "Executing Member 1 (Content) & Member 2 (Metadata/Format) engines...")
        try:
            m3_result = run_member3_analysis(file_path)
            if m3_result and m3_result.get("success"):
                raw_ev = m3_result.get("evidence", [])
                for idx, ev in enumerate(raw_ev, 1):
                    sev = ev.get("strength", "LOW").upper()
                    if sev not in ["HIGH", "MEDIUM", "LOW"]:
                        sev = "MEDIUM"
                    cat = ev.get("category", "CONTENT").lower()
                    if cat == "formatting":
                        cat = "format"

                    m3_evidence_items.append({
                        "id": f"E{idx:02d}",
                        "internal_id": ev.get("evidence_id", f"E{idx:02d}"),
                        "category": cat,
                        "severity": sev,
                        "title": ev.get("type", "Forensic Indicator").replace("_", " ").title(),
                        "page": ev.get("page") or 1,
                        "region": ev.get("region") or f"Document {cat.capitalize()}",
                        "description": ev.get("description", "Potential irregularity observed."),
                        "bbox": None
                    })
        except Exception as e:
            logger.warning("Member 3 execution fallback: %s", e)

    # 2. Run Member 4 visual ELA and bounding box detection (for Suspicious Regions preview)
    if progress_callback:
        progress_callback(0.65, "Running Error Level Analysis (ELA) and visual bounding box scanner...")
    try:
        visual_res = analyze_visual(file_path)
    except Exception as e:
        visual_res = {
            "category": "visual",
            "severity": "CLEAN",
            "findings_count": 0,
            "checks_performed": 1,
            "checks_total": 2,
            "findings": [],
            "regions": [],
        }

    # 3. Run supplemental local engines for additional verification
    if progress_callback:
        progress_callback(0.8, "Correlating forensic signals across categories...")
    try:
        content_res = analyze_content(file_path)
        format_res = analyze_formatting(file_path)
        meta_res = analyze_metadata(file_path)
    except Exception:
        content_res = {"category": "content", "severity": "CLEAN", "findings": [], "checks_performed": 2, "checks_total": 3}
        format_res = {"category": "format", "severity": "CLEAN", "findings": [], "checks_performed": 2, "checks_total": 2}
        meta_res = {"category": "metadata", "severity": "CLEAN", "findings": [], "checks_performed": 2, "checks_total": 3, "raw_metadata": {}}

    # Merge evidence: combine Member 3 evidence with Member 4 visual & structural evidence
    local_ev, local_regions = aggregate_evidence(content_res, format_res, meta_res, visual_res)
    all_evidence = m3_evidence_items if m3_evidence_items else local_ev

    # Add visual ELA evidence if detected
    for lev in local_ev:
        if lev["category"] == "visual" and not any(e.get("title") == lev.get("title") for e in all_evidence):
            all_evidence.append(lev)

    # Sort & re-index cleanly: HIGH -> MEDIUM -> LOW
    sev_rank = {"HIGH": 0, "MEDIUM": 1, "ELEVATED": 1, "LOW": 2}
    all_evidence.sort(key=lambda x: sev_rank.get(x["severity"], 3))
    for i, ev in enumerate(all_evidence, 1):
        ev["id"] = f"E{i:02d}"

    suspicious_regions = visual_res.get("regions", local_regions)

    doc_info = {
        "filename": filename,
        "file_type": file_type,
        "pages": pages,
        "sha256": sha256,
        "short_sha256": short_sha256,
        "file_size": file_size_formatted,
        "file_path": file_path,
    }

    # 4. Gemma Reasoning Synthesis
    if progress_callback:
        progress_callback(0.9, "Synthesizing tampering hypotheses with Gemma Reasoning Engine...")

    ai_assessment_text = None
    ai_source = "Gemma 4 Forensic Reasoner (Member 3 Integrated)"

    # Check if Member 3's Gemma returned a valid response
    if m3_result and isinstance(m3_result.get("gemma"), dict) and m3_result["gemma"].get("status") == "success":
        analysis_data = m3_result["gemma"].get("analysis", {})
        if isinstance(analysis_data, dict):
            ai_assessment_text = analysis_data.get("executive_summary") or str(analysis_data)
        elif isinstance(analysis_data, str):
            ai_assessment_text = analysis_data

    # Fallback to Member 4 Gemma Reasoning Engine if API key was missing or failed
    if not ai_assessment_text:
        ai_res = analyze_with_gemma(all_evidence, doc_info)
        ai_assessment_text = ai_res.get("assessment", "Analysis complete.")
        ai_source = ai_res.get("source", "Gemma Forensic Reasoner")

    # 5. Risk & Hypotheses Evaluation
    risk_evaluation = evaluate_risk_and_hypotheses(
        all_evidence, content_res, format_res, meta_res, visual_res
    )

    # 6. Build Standard Unified Case Object
    case_object: Dict[str, Any] = {
        "document": doc_info,
        "summary": risk_evaluation["summary"],
        "categories": risk_evaluation["categories"],
        "evidence": all_evidence,
        "regions": suspicious_regions,
        "hypotheses": risk_evaluation["hypotheses"],
        "origin_indicators": risk_evaluation["origin_indicators"],
        "recommendations": risk_evaluation["recommendations"],
        "ai_assessment": ai_assessment_text,
        "ai_source": ai_source,
        "raw_metadata": meta_res.get("raw_metadata", {}),
        "member_results": {
            "has_member1_2_3": bool(m3_result and m3_result.get("success")),
            "member3_gemma_status": m3_result.get("gemma", {}).get("status") if m3_result else None
        }
    }

    # 7. Persist to Database for Recent History
    try:
        case_id = save_case(case_object)
        case_object["id"] = case_id
    except Exception:
        pass

    if progress_callback:
        progress_callback(1.0, "Analysis complete!")

    return case_object

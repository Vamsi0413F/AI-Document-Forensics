import os
import io
import tempfile
from typing import Tuple, List, Optional
from PIL import Image
import fitz  # PyMuPDF


SUPPORTED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg"}
MAX_FILE_SIZE_BYTES = 30 * 1024 * 1024  # 30 MB


def validate_file(filename: str, byte_size: int) -> Tuple[bool, Optional[str]]:
    """
    Validates file extension and size.
    Returns (is_valid, error_message).
    """
    ext = os.path.splitext(filename)[1].lower()
    if ext not in SUPPORTED_EXTENSIONS:
        return (
            False,
            f"Unsupported file format '{ext}'. Only PDF, PNG, and JPG/JPEG files are supported.",
        )

    if byte_size > MAX_FILE_SIZE_BYTES:
        return (
            False,
            f"File size exceeds maximum limit of {MAX_FILE_SIZE_BYTES // (1024 * 1024)}MB.",
        )

    if byte_size == 0:
        return False, "File is empty (0 bytes)."

    return True, None


def get_file_type_label(filename: str) -> str:
    ext = os.path.splitext(filename)[1].lower()
    if ext == ".pdf":
        return "PDF"
    elif ext in {".png"}:
        return "PNG"
    elif ext in {".jpg", ".jpeg"}:
        return "JPEG"
    return ext.replace(".", "").upper()


def save_temp_file(file_bytes: bytes, filename: str) -> str:
    """Save bytes to a temporary directory preserving extension."""
    temp_dir = os.path.join(tempfile.gettempdir(), "veridoc_uploads")
    os.makedirs(temp_dir, exist_ok=True)
    safe_name = os.path.basename(filename)
    path = os.path.join(temp_dir, safe_name)
    with open(path, "wb") as f:
        f.write(file_bytes)
    return path


def extract_document_pages_as_images(file_path: str, max_pages: int = 5) -> List[Image.Image]:
    """
    Renders document pages as PIL Images for preview and visual analysis.
    For PDF, renders using PyMuPDF (fitz) at 150 DPI.
    For images, loads the PIL image directly.
    """
    images: List[Image.Image] = []
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".pdf":
        try:
            doc = fitz.open(file_path)
            num_pages = min(len(doc), max_pages)
            for page_idx in range(num_pages):
                page = doc[page_idx]
                pix = page.get_pixmap(dpi=150)
                img = Image.open(io.BytesIO(pix.tobytes("png")))
                images.append(img)
            doc.close()
        except Exception as e:
            # Fallback or error placeholder
            placeholder = Image.new("RGB", (600, 800), color=(240, 240, 240))
            images.append(placeholder)
    elif ext in {".png", ".jpg", ".jpeg"}:
        try:
            img = Image.open(file_path).convert("RGB")
            images.append(img)
        except Exception:
            placeholder = Image.new("RGB", (600, 800), color=(240, 240, 240))
            images.append(placeholder)

    return images


def get_page_count(file_path: str) -> int:
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".pdf":
        try:
            doc = fitz.open(file_path)
            count = len(doc)
            doc.close()
            return count
        except Exception:
            return 1
    return 1

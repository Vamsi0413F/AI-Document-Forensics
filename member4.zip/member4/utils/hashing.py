import hashlib
from typing import Union, Tuple


def calculate_hashes(data_or_path: Union[bytes, str]) -> dict:
    """
    Calculate SHA-256 and MD5 hashes from raw bytes or a file path.
    Returns a dict with full hashes and formatted short representations.
    """
    if isinstance(data_or_path, str):
        with open(data_or_path, "rb") as f:
            content = f.read()
    else:
        content = data_or_path

    sha256 = hashlib.sha256(content).hexdigest()
    md5 = hashlib.md5(content).hexdigest()

    short_sha256 = f"{sha256[:4]}...{sha256[-4:]}" if len(sha256) >= 8 else sha256

    return {
        "sha256": sha256,
        "md5": md5,
        "short_sha256": short_sha256,
        "byte_size": len(content),
    }


def format_file_size(num_bytes: int) -> str:
    """Format bytes into human-readable string (KB, MB)."""
    for unit in ["B", "KB", "MB", "GB"]:
        if num_bytes < 1024.0:
            return f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024.0
    return f"{num_bytes:.1f} TB"
